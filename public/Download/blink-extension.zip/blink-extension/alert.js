// ─── Blink Extension — Alert Window Script ───────────────────────────────────
// This window is opened by background.js when a rest begins.
// Because this is a real window, Web Audio API works fully here.

import { renderTone, TONE_SAMPLE_RATE } from './src/tones.js';

const REST_SEC = 20;

// ── read initial seconds from URL param ──────────────────────────────────────
const params  = new URLSearchParams(location.search);
let remaining = Math.min(REST_SEC, Math.max(1, parseInt(params.get('sec') || REST_SEC, 10)));
const total   = remaining;

// ── DOM ───────────────────────────────────────────────────────────────────────
const countdownEl  = document.getElementById('countdown');
const progressBar  = document.getElementById('progressBar');
const btnDone      = document.getElementById('btnDone');
const btnMute      = document.getElementById('btnMute');

function fmt(sec) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function updateUI(sec) {
  countdownEl.textContent = fmt(sec);
  progressBar.style.width = `${(sec / total) * 100}%`;
}
updateUI(remaining);

// ── Audio ─────────────────────────────────────────────────────────────────────
let audioCtx     = null;
let activeSource = null;
let activeGain   = null;
let muted        = false;

async function startAudio(durationSec) {
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state !== 'running') await audioCtx.resume();

    const samples = renderTone('gentle-chime', TONE_SAMPLE_RATE);
    const buffer  = audioCtx.createBuffer(1, samples.length, TONE_SAMPLE_RATE);
    buffer.copyToChannel(samples, 0);

    const src  = audioCtx.createBufferSource();
    const gain = audioCtx.createGain();
    src.buffer = buffer;
    src.loop   = true;
    src.connect(gain);
    gain.connect(audioCtx.destination);
    gain.gain.value = 0.75;

    const startAt = audioCtx.currentTime + 0.05;
    const endAt   = startAt + durationSec;
    // gentle fade out at the end
    gain.gain.setValueAtTime(0.75, Math.max(startAt, endAt - 0.5));
    gain.gain.linearRampToValueAtTime(0, endAt);

    src.start(startAt);
    src.stop(endAt);
    activeSource = src;
    activeGain   = gain;
    src.onended  = () => { activeSource = null; activeGain = null; };
  } catch (error) {
    console.error('[Blink alert] audio failed:', error);
  }
}

function stopAudio() {
  if (activeSource) {
    try {
      const now = audioCtx.currentTime;
      if (activeGain) {
        activeGain.gain.cancelScheduledValues(now);
        activeGain.gain.setValueAtTime(activeGain.gain.value, now);
        activeGain.gain.linearRampToValueAtTime(0, now + 0.015);
      }
      activeSource.stop(now + 0.02);
    } catch (_) {}
    activeSource = null; activeGain = null;
  }
}

// Auto-start audio as soon as window opens (user gesture not needed here
// because the window was opened by Chrome itself — it counts as activated)
startAudio(remaining);

// ── Countdown ticker ──────────────────────────────────────────────────────────
const startWall = Date.now();
const endsAt    = startWall + remaining * 1000;

const ticker = setInterval(() => {
  const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
  remaining  = left;
  updateUI(left);
  if (left <= 0) {
    clearInterval(ticker);
    stopAudio();
    // Auto-close after a moment
    setTimeout(() => window.close(), 800);
  }
}, 250);

// ── background tick sync (keeps countdown accurate if tab was throttled) ──────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'TICK' && message.secondsLeft !== undefined) {
    remaining = message.secondsLeft;
    updateUI(remaining);
  }
  if (message.type === 'REST_END') {
    clearInterval(ticker);
    stopAudio();
    setTimeout(() => window.close(), 400);
  }
});

// ── buttons ───────────────────────────────────────────────────────────────────
btnDone.addEventListener('click', async () => {
  clearInterval(ticker);
  stopAudio();
  try {
    await chrome.runtime.sendMessage({ type: 'REST_DONE_BY_USER' });
  } catch (_) {}
  window.close();
});

btnMute.addEventListener('click', () => {
  muted = !muted;
  if (muted) {
    stopAudio();
    btnMute.textContent = '🔊 Unmute';
  } else {
    startAudio(remaining);
    btnMute.textContent = '🔇 Mute';
  }
});

// If user closes window manually — tell background
window.addEventListener('beforeunload', () => {
  // Only fire if still in rest phase (not already ended)
  if (remaining > 0) {
    chrome.runtime.sendMessage({ type: 'REST_DONE_BY_USER' }).catch(() => {});
  }
});
