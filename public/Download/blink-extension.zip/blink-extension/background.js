// ─── Blink Extension — Background Service Worker v1.1 ────────────────────────
// Uses chrome.alarms so timer survives SW termination and browser minimize.
// When rest starts: opens a floating alert window + sends system notification.

const FOCUS_SEC = 20 * 60;
const REST_SEC  = 20;
const ALARM_TICK      = 'blink-tick';
const ALARM_FOCUS_END = 'blink-focus-end';
const ALARM_REST_END  = 'blink-rest-end';

let alertWindowId = null; // track the open alert window

// ── state helpers ─────────────────────────────────────────────────────────────
async function getState() {
  const { blinkState } = await chrome.storage.local.get('blinkState');
  return blinkState || {
    phase: 'stopped', endsAt: null, secondsLeft: FOCUS_SEC,
    completed: 0, lastRest: 'Not yet today'
  };
}
async function setState(patch) {
  const current = await getState();
  const next = { ...current, ...patch };
  await chrome.storage.local.set({ blinkState: next });
  return next;
}
function timeLabel() {
  return new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}
async function clearAlarms() {
  await Promise.all([
    chrome.alarms.clear(ALARM_FOCUS_END),
    chrome.alarms.clear(ALARM_REST_END),
    chrome.alarms.clear(ALARM_TICK),
  ]);
}
async function scheduleAlarms(phase, endsAt) {
  await clearAlarms();
  if (phase === 'focus') chrome.alarms.create(ALARM_FOCUS_END, { when: endsAt });
  if (phase === 'rest')  chrome.alarms.create(ALARM_REST_END,  { when: endsAt });
  chrome.alarms.create(ALARM_TICK, { periodInMinutes: 15 / 60 }); // every 15s
}

// ── update toolbar badge ──────────────────────────────────────────────────────
async function updateBadge(state) {
  const { phase, secondsLeft } = state;
  if (phase === 'focus') {
    const m = Math.ceil(secondsLeft / 60);
    chrome.action.setBadgeText({ text: `${m}m` });
    chrome.action.setBadgeBackgroundColor({ color: '#ed7442' });
  } else if (phase === 'rest') {
    chrome.action.setBadgeText({ text: 'REST' });
    chrome.action.setBadgeBackgroundColor({ color: '#79b5a5' });
  } else if (phase === 'paused') {
    chrome.action.setBadgeText({ text: '⏸' });
    chrome.action.setBadgeBackgroundColor({ color: '#555' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// ── alert window ──────────────────────────────────────────────────────────────
async function openAlertWindow(secondsLeft) {
  // Close any existing alert window first
  if (alertWindowId !== null) {
    try { await chrome.windows.remove(alertWindowId); } catch (_) {}
    alertWindowId = null;
  }
  const alertUrl = chrome.runtime.getURL(`alert.html?sec=${secondsLeft}`);
  const win = await chrome.windows.create({
    url: alertUrl,
    type: 'popup',
    width: 380,
    height: 340,
    focused: true,
    top: 40,
    left: 40,
  });
  alertWindowId = win.id;
}

async function closeAlertWindow() {
  if (alertWindowId !== null) {
    try { await chrome.windows.remove(alertWindowId); } catch (_) {}
    alertWindowId = null;
  }
}

// Track if alert window is closed by user (not by us)
chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === alertWindowId) alertWindowId = null;
});

// ── notification ──────────────────────────────────────────────────────────────
function sendNotification(id, title, message) {
  chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    priority: 2,
    requireInteraction: true,
  });
}

// ── tick update ───────────────────────────────────────────────────────────────
async function tickUpdate() {
  const state = await getState();
  if (state.phase !== 'focus' && state.phase !== 'rest') return;
  const remaining = Math.max(0, Math.ceil((state.endsAt - Date.now()) / 1000));
  const updated = await setState({ secondsLeft: remaining });
  await updateBadge(updated);
  // Forward tick to alert window if open
  chrome.runtime.sendMessage({ type: 'TICK', secondsLeft: remaining }).catch(() => {});
}

// ── alarm handler ─────────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_TICK) {
    await tickUpdate();
    return;
  }

  if (alarm.name === ALARM_FOCUS_END) {
    const now    = Date.now();
    const endsAt = now + REST_SEC * 1000;
    const next   = await setState({ phase: 'rest', secondsLeft: REST_SEC, endsAt });
    await scheduleAlarms('rest', endsAt);
    await updateBadge(next);

    // 1. System notification
    sendNotification('blink-rest-start',
      '👁  Time to rest your eyes',
      'Look 20 feet away for 20 seconds. Blink is opening a rest reminder.'
    );

    // 2. Alert window on screen
    await openAlertWindow(REST_SEC);

    // 3. Tell popup if open
    chrome.runtime.sendMessage({ type: 'REST_START', secondsLeft: REST_SEC }).catch(() => {});
    return;
  }

  if (alarm.name === ALARM_REST_END) {
    const now       = Date.now();
    const state     = await getState();
    const completed = (state.completed || 0) + 1;
    const endsAt    = now + FOCUS_SEC * 1000;
    const next      = await setState({
      phase: 'focus', secondsLeft: FOCUS_SEC, endsAt, completed, lastRest: timeLabel()
    });
    await scheduleAlarms('focus', endsAt);
    await updateBadge(next);
    await closeAlertWindow();

    sendNotification('blink-rest-done',
      '✅  Rest complete — well done!',
      `Cycle ${completed} done. Next reminder in 20 minutes.`
    );

    chrome.runtime.sendMessage({ type: 'REST_END', completed }).catch(() => {});
  }
});

// ── message handler (from popup / alert window) ───────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    const state = await getState();
    const now   = Date.now();

    if (message.type === 'GET_STATE') {
      let secondsLeft = state.secondsLeft;
      if ((state.phase === 'focus' || state.phase === 'rest') && state.endsAt) {
        secondsLeft = Math.max(0, Math.ceil((state.endsAt - now) / 1000));
      }
      sendResponse({ ...state, secondsLeft });
      return;
    }

    if (message.type === 'START') {
      if (state.phase === 'focus' || state.phase === 'rest') { sendResponse(state); return; }
      let endsAt, phase, secondsLeft;
      if (state.phase === 'paused') {
        phase       = state.pausedFrom || 'focus';
        secondsLeft = Math.max(1, state.secondsLeft);
        endsAt      = now + secondsLeft * 1000;
      } else {
        phase = 'focus'; secondsLeft = FOCUS_SEC; endsAt = now + FOCUS_SEC * 1000;
      }
      const next = await setState({ phase, secondsLeft, endsAt, pausedFrom: null });
      await scheduleAlarms(phase, endsAt);
      await updateBadge(next);
      sendResponse(next);
      return;
    }

    if (message.type === 'PAUSE') {
      if (state.phase !== 'focus' && state.phase !== 'rest') { sendResponse(state); return; }
      const remaining = Math.max(1, Math.ceil((state.endsAt - now) / 1000));
      const next = await setState({
        phase: 'paused', pausedFrom: state.phase, secondsLeft: remaining, endsAt: null
      });
      await clearAlarms();
      await updateBadge(next);
      sendResponse(next);
      return;
    }

    if (message.type === 'RESET') {
      await closeAlertWindow();
      const next = await setState({
        phase: 'stopped', endsAt: null, secondsLeft: FOCUS_SEC, pausedFrom: null
      });
      await clearAlarms();
      await updateBadge(next);
      sendResponse(next);
      return;
    }

    if (message.type === 'REST_DONE_BY_USER') {
      // User closed alert window early — still move to next focus cycle
      await closeAlertWindow();
      const completed = (state.completed || 0) + 1;
      const endsAt    = now + FOCUS_SEC * 1000;
      const next      = await setState({
        phase: 'focus', secondsLeft: FOCUS_SEC, endsAt, completed, lastRest: timeLabel()
      });
      await scheduleAlarms('focus', endsAt);
      await updateBadge(next);
      sendResponse(next);
      return;
    }
  })();
  return true;
});

// ── install / startup ─────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  await setState({
    phase: 'stopped', endsAt: null, secondsLeft: FOCUS_SEC,
    completed: 0, lastRest: 'Not yet today'
  });
  await updateBadge({ phase: 'stopped' });
});

chrome.runtime.onStartup.addListener(async () => {
  const state = await getState();
  if ((state.phase === 'focus' || state.phase === 'rest') && state.endsAt > Date.now()) {
    await scheduleAlarms(state.phase, state.endsAt);
    await updateBadge(state);
  } else if (state.phase === 'focus' || state.phase === 'rest') {
    // Missed while browser was closed — reset cleanly
    const next = await setState({ phase: 'stopped', endsAt: null, secondsLeft: FOCUS_SEC });
    await updateBadge(next);
    await clearAlarms();
  }
});
