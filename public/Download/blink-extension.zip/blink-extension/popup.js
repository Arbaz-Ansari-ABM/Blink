// ─── Blink Extension — Popup Script v1.1 ─────────────────────────────────────
import { renderTone, TONE_SAMPLE_RATE } from './src/tones.js';

const FOCUS_SEC     = 20 * 60;
const REST_SEC      = 20;
const CIRCUMFERENCE = 2 * Math.PI * 52;

// ── DOM ───────────────────────────────────────────────────────────────────────
const dot           = document.querySelector('.live-dot');
const phaseLabel    = document.getElementById('phaseLabel');
const timerLabel    = document.getElementById('timerLabel');
const timerTime     = document.getElementById('timerTime');
const timerSub      = document.getElementById('timerSub');
const ringProgress  = document.getElementById('ringProgress');
const restAlert     = document.getElementById('restAlert');
const restCountdown = document.getElementById('restCountdown');
const btnStart      = document.getElementById('btnStart');
const btnReset      = document.getElementById('btnReset');
const btnMute       = document.getElementById('btnMute');
const statCompleted = document.getElementById('statCompleted');
const statLast      = document.getElementById('statLast');

// ── audio (popup) — only plays if popup is open ───────────────────────────────
let audioCtx     = null;
let activeSource = null;
let activeGain   = null;
let soundEnabled = true;

function getCtx() {
  if (!audioCtx || audioCtx.state === 'closed')
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

function stopSound() {
  if (!activeSource) return;
  try {
    const ctx = getCtx();
    if (activeGain) {
      activeGain.gain.setValueAtTime(activeGain.gain.value, ctx.currentTime);
      activeGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.015);
    }
    activeSource.stop(ctx.currentTime + 0.02);
  } catch (_) {}
  activeSource = null; activeGain = null;
}

async function playRestTone(durationSec = REST_SEC) {
  if (!soundEnabled) return;
  stopSound();
  try {
    const ctx = getCtx();
    if (ctx.state !== 'running') await ctx.resume();
    const samples = renderTone('gentle-chime', TONE_SAMPLE_RATE);
    const buffer  = ctx.createBuffer(1, samples.length, TONE_SAMPLE_RATE);
    buffer.copyToChannel(samples, 0);
    const src  = ctx.createBufferSource();
    const gain = ctx.createGain();
    src.buffer = buffer; src.loop = true;
    src.connect(gain); gain.connect(ctx.destination);
    gain.gain.value = 0.75;
    const st = ctx.currentTime + 0.02, en = st + durationSec;
    gain.gain.setValueAtTime(0.75, Math.max(st, en - 0.03));
    gain.gain.linearRampToValueAtTime(0, en);
    src.start(st); src.stop(en);
    activeSource = src; activeGain = gain;
    src.onended = () => { if (activeSource === src) { activeSource = null; activeGain = null; } };
  } catch (err) { console.error('[Blink popup] audio:', err); }
}

// ── format ────────────────────────────────────────────────────────────────────
function fmt(sec) {
  return `${Math.floor(sec/60).toString().padStart(2,'0')}:${(sec%60).toString().padStart(2,'0')}`;
}

// ── render ────────────────────────────────────────────────────────────────────
let lastPhase = null;
function render(state) {
  const { phase, secondsLeft = 0, completed = 0, lastRest = '—' } = state;
  const isRest    = phase === 'rest';
  const isRunning = phase === 'focus' || phase === 'rest';
  const isPaused  = phase === 'paused';

  dot.className = 'live-dot' + (isRest?' rest':isRunning?' running':isPaused?' paused':'');
  phaseLabel.textContent = isRest?'Rest':isPaused?'Paused':phase==='stopped'?'Ready':'Focus';

  const total = isRest ? REST_SEC : FOCUS_SEC;
  const prog  = Math.max(0, Math.min(1, 1 - secondsLeft/total));
  ringProgress.style.strokeDashoffset = CIRCUMFERENCE * (1 - prog);
  ringProgress.classList.toggle('rest', isRest);

  timerLabel.textContent = isRest?'REST':isPaused?'PAUSED':'FOCUS';
  timerTime.textContent  = fmt(secondsLeft);
  timerSub.textContent   = isRest?'look 20 ft away':isPaused?'tap to resume':phase==='stopped'?'20-min focus':'until rest';

  restAlert.hidden = !isRest;
  if (isRest) restCountdown.textContent = fmt(secondsLeft);

  btnStart.textContent = isRunning ? '⏸ Pause' : isPaused ? '▶ Resume' : '▶ Start';
  btnStart.classList.toggle('pausing', isRunning);

  statCompleted.textContent = completed;
  statLast.textContent      = lastRest || '—';

  if (phase === 'rest' && lastPhase !== 'rest') playRestTone(secondsLeft);
  if (phase !== 'rest' && lastPhase === 'rest') stopSound();
  lastPhase = phase;
}

// ── poll ──────────────────────────────────────────────────────────────────────
let pollId = null;
async function poll() {
  try {
    const state = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
    if (state) render(state);
  } catch (_) {}
}
document.addEventListener('DOMContentLoaded', () => {
  // Open the website in a normal Chrome tab before the popup closes.
  const visitBlinkLink = document.getElementById('visitBlink');
  if (visitBlinkLink) {
    visitBlinkLink.addEventListener('click', (event) => {
      event.preventDefault();
      chrome.tabs.create({ url: 'https://eyescomfortz.vercel.app/' });
    });
  }

  poll();
  pollId = setInterval(poll, 500);
});
window.addEventListener('unload', () => { clearInterval(pollId); stopSound(); });

// ── background messages ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'REST_START') {
    poll().then(() => playRestTone(message.secondsLeft || REST_SEC));
  }
  if (message.type === 'REST_END') { stopSound(); poll(); }
  if (message.type === 'TICK')     { poll(); }
});

// ── buttons ───────────────────────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
  try { const c=getCtx(); if(c.state!=='running') await c.resume(); } catch(_){}
  const state = await chrome.runtime.sendMessage({ type: 'GET_STATE' });
  const isRunning = state.phase==='focus' || state.phase==='rest';
  const next = await chrome.runtime.sendMessage({ type: isRunning?'PAUSE':'START' });
  if (next) render(next);
});

btnReset.addEventListener('click', async () => {
  stopSound();
  const next = await chrome.runtime.sendMessage({ type: 'RESET' });
  if (next) render(next);
});

btnMute.addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  if (!soundEnabled) stopSound();
  btnMute.textContent = soundEnabled ? '🔇 Stop sound' : '🔊 Unmute';
});
